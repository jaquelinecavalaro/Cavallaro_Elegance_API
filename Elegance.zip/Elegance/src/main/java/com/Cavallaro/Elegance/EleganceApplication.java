package com.Cavallaro.Elegance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EleganceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EleganceApplication.class, args);
	}

}
