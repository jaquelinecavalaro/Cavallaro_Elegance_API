package com.Cavallaro.Elegance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EleganceApplicationTests {

	@Test
	void contextLoads() {
	}

}
